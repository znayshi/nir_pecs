package com.cmi.presentation.manager

object FileProviderManager {
    const val AUTHORITY = "com.rguzman.cmi.fileprovider"
}